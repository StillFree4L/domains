<div>
<?php

    echo $form->textFieldRow($this->model, 'label', array("class"=>"span3"));

?>
</div>
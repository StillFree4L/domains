<div>
<?php

    echo $form->textFieldRow($this->model, 'caption', array("class"=>"span5"));

?>
</div>
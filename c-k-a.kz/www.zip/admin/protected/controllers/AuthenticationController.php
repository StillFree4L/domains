<?php
class AuthenticationController extends BaseController
{
	/**
	 * Declares class-based actions.
	 */
        public $layout='//layouts/auth';
        public $defaultAction = "login";

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
	    if($error=Yii::app()->errorHandler->error)
	    {
	    	if(Yii::app()->request->isAjaxRequest)
	    		echo $error['message'];
	    	else
	        	$this->render('error', $error);
	    }
	}

	/**
	 * Displays the login page
	 */
	public function actionLogin()
	{


                $model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['LoginForm']))
		{
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login())
                        {
                                $this->redirect(Yii::app()->user->returnUrl);
                        }
		}
		// display the login form
                //$baseUrl = Yii::app()->assetManager->publish($assets,false,-1,true);
		Yii::app()->getClientScript()->registerCssFile('/admin/css/authentication/authentication.css');
		$this->render('login',array('model'=>$model));
	}
        
        function actionRegistrationComplete()
        {
            $this->render("registrationComplete");            
        }
        
        function actionActivate()
        {
            if (isset($_GET['account']))
            {
                if (Users::model()->activate($_GET['account']))
                {
                    $this->render("activated");
                } else {
                    Yii::app()->request->redirect("/");
                }
            }
        }

        function actionRegistration()
        {
            $model = new Users();
            
            if (isset($_POST['Users']))
            {
                
                $model->attributes = $_POST['Users'];
                $model->organization = $_POST['Users']['organization'];
                if ($model->validate() AND $model->save()) 
                {
                    
                    Yii::import('application.extensions.phpmailer.JPhpMailer');
                    $mail = new JPhpMailer;
                    $mail->IsSMTP();
                    $mail->CharSet = 'utf-8';  
                    $mail->Host = 'c-k-a.kz';
                    //$mail->SMTPAuth = true;
                    //$mail->Username = 'yourname@163.com';
                    //$mail->Password = 'yourpassword';
                    $mail->SetFrom('admin@c-k-a.kz', 'Центрально-Казахстанская академия');
                    $mail->Subject = 'Активация вашего аккаунта';                   
                    $mail->MsgHTML('Для того чтобы завершить регистрацию вашего аккаунта на сайте Центрально-Казахстанская академия пройдите по ссылке <a href="http://c-k-a.kz/admin/authentication/activate/account/'.$model->id.'">http://c-k-a.kz/admin/authentication/activate/account/'.$model->id.'</a>');
                    $mail->AddAddress($model->email);
                    $mail->Send();
                    
                    Yii::app()->request->redirect( '/admin/'.Yii::app()->language.'/'.Yii::app ()->controller->id."/registrationComplete" );
                }
                
                
            }
            
            $this->render("registration", array(
                "model"=>$model,
            ));
        }

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		$this->redirect("/");
	}
}
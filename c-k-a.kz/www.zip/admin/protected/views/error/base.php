<div class="alert alert-error">
    <strong>404</strong> <?=t('Ошибка. Страница не найдена.')?>
</div>

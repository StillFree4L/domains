<?php
    $this->widget("ext.EMenu.EMenuBuilder");
?>
<?php
$this->widget("ext.EInstance.EInstanceAdd", array(
    "baseFields"=>array("label","caption","type"),
    "model"=>$model
));
?>
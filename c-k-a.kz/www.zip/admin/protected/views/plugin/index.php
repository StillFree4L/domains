<?php
$this->widget("frontend.plugins.".$plugin->uniq_name.".".$plugin->uniq_name."_admin", array(
    
));
?>
<?php
$this->widget("ext.EInstance.EInstanceAdd", array(
    "model"=>$model,
    "type"=>"2",
    "baseFields"=>array(
        "caption",
        "preview",
        "body",
        "is_c",
    ),
    "sideFields"=>array(
        "state",
        "categories"
    )
));
?>
<div class="control-group well well-small span6" style="margin:30px auto; float:none">
    <div class="alert alert-message">
    <?php

        echo t("Ваш аккаунт успешно активирован. Для того чтобы войти на сайт пройдите по ссылке ")."<a href='/admin/authentication/login'>".t("Войти")."</a>";

    ?>
    </div>
</div>

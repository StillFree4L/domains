<div class="control-group well well-small span6" style="margin:30px auto; float:none">
    <div class="alert alert-message">
    <?php

        echo t("Регистрация аккаунта успешно выполнена. На ваш почтовый адрес выслано письмо с активацией аккаунта.")

    ?>
    </div>
</div>

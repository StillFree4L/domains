<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => '',
  'modelPath' => 'application.models',
  'baseClass' => 'BaseActiveRecord',
  'buildRelations' => '1',
);

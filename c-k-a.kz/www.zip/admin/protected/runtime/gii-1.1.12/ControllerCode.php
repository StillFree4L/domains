<?php
return array (
  'template' => 'default',
  'baseClass' => 'BaseController',
  'actions' => 'index',
);

#!/bin/sh

cd ~alex/www/rev/app

../framework/yiic message2 ./protected/messages/config.php




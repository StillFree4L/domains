$(function() {
    MainController = BaseController.extend({

        actionIndex : BaseAction.extend({

            _initialize : function() {

            }

        })

    })

})
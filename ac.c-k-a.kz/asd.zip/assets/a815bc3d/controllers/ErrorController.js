$(function() {
    ErrorController = BaseController.extend({

        actionIndex : BaseAction.extend({

            _initialize : function() {

            }

        })

    })

})
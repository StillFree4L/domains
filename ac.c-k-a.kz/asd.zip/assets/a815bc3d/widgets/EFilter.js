$(function() {

    EFilter  = BaseWidget.extend({



    })

})
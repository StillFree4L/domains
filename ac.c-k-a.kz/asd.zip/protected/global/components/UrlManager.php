<?php
namespace glob\components;

class UrlManager extends \yii\web\UrlManager
{

    public $langParam = "ln";
    public $languages = ["ru-RU","en-US"];


}
?>
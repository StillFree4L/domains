<?php
return [
         "Запомнить"=>"remember_"  
     ];
?>    
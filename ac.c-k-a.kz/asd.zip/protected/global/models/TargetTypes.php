<?php

namespace glob\models;

class TargetTypes
{
    const user = 1;
    const platform = 2;
    const order = 3;
    const rivalPlatform = 4;
    const rivalOrder = 5;
    const chat = 6;
}
?>
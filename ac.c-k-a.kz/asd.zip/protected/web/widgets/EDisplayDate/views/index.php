<i class="fa fa-clock-o"></i> <time>
    <?php
        echo $label;
    ?>
</time>
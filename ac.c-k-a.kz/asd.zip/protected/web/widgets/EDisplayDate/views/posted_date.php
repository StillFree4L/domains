<i class="fa fa-clock-o"></i> <time ts="<?=$this->context->time?>" ft="<?=$this->context->formatType?>">
    <?php
      	echo $label;
    ?>
</time>
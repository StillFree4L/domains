<?php
return [
    2 => [
        'type' => 1,
    ],
    8 => [
        'type' => 1,
    ],
    3 => [
        'type' => 1,
    ],
    9 => [
        'type' => 1,
    ],
    4 => [
        'type' => 1,
    ],
    1 => [
        'type' => 1,
        'children' => [
            2,
            8,
            3,
            9,
            4,
        ],
    ],
    999 => [
        'type' => 1,
        'children' => [
            1,
        ],
    ],
];

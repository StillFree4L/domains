<?php
    $this->setTitle(Yii::t("main","Главная"), false);
?>

<div class="controller container">
    <div class="action-content">



    </div>
</div>
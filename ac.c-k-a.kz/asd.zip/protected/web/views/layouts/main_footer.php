<footer class="hidden-print">
    <nav class="navbar navbar-default" style="border-radius:0; margin-bottom:0;">
        <div class="container">
            <div class="collapse navbar-collapse" style="padding:0;">
                <ul class="nav navbar-nav pull-right">

                </ul>
            </div>
        </div>
    </nav>
</footer>

<header class="auth-header">

    <div class="container text-center">

        <h1><a class="logo" href="<?=\glob\helpers\Common::createUrl("/main/index")?>"></a></h1>

    </div>


</header>
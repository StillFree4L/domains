<?php

error_reporting(E_ALL & ~E_NOTICE);

// comment out the following two lines when deployed to production
defined('YII_DEBUG') or define('YII_DEBUG', strpos($_SERVER['SERVER_NAME'], "dev") !== false ? true : false);
defined('YII_ENV') or define('YII_ENV', 'dev');

require(__DIR__ . '/protected/vendors/autoload.php');
require(__DIR__ . '/protected/vendors/yiisoft/yii2/Yii.php');
$config = require(__DIR__ . '/protected/config/web.php');

(new yii\web\Application($config))->run();
